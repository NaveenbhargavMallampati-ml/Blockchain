// function Footer()
// {
//     return(
//         <div id="footer">
//             <footer>By proceeding to create your account you are agreeing to our <a href="https://www.turito.com/terms-conditions"><strong>Terms of Service</strong></a> and <a href="https://www.turito.com/privacy-policy"><strong>Privacy Policy</strong></a></footer> 
//         </div>
//     );
// }

// export default Footer;